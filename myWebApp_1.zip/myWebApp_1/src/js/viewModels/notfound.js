define([], function () {
    function NotFoundViewModel() {
        // Empty or logging logic here
    }
    return new NotFoundViewModel();
});